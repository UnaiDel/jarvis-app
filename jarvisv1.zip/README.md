# Jarvis App

This is a full-stack application that integrates GPT-3 and Firebase for an AI-driven assistant. The project includes both frontend (React) and backend (Node.js) components.

## How to Run

1. Clone the repository.
2. Install the dependencies with `npm install` in both `backend` and `frontend` directories.
3. Run the backend with `npm run dev` inside the `backend` directory.
4. Run the frontend with `npm start` inside the `frontend` directory.

## Dependencies

- Node.js
- React
- Firebase
- MongoDB
