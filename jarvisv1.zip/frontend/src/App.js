// Contenido de App.js
import React, { useState } from 'react';
import ChatGptForm from './components/ChatGptForm';
import ResponseDisplay from './components/ResponseDisplay';

const App = () => {
  const [response, setResponse] = useState('');

  return (
    <div>
      <h1>Jarvis App</h1>
      <ChatGptForm setResponse={setResponse} />
      <ResponseDisplay response={response} />
    </div>
  );
};

export default App;
