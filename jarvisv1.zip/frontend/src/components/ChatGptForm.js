// Contenido de ChatGptForm.js
import React, { useState } from 'react';

const ChatGptForm = () => {
  const [prompt, setPrompt] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Lógica para enviar la solicitud al backend
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />
      <button type="submit">Send</button>
    </form>
  );
};

export default ChatGptForm;
