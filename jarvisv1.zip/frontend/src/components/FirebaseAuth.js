// Contenido de FirebaseAuth.js
import React, { useEffect } from 'react';
import firebase from 'firebase/app';
import 'firebase/auth';

const FirebaseAuth = () => {
  useEffect(() => {
    const auth = firebase.auth();
    auth.onAuthStateChanged((user) => {
      if (user) {
        console.log('User signed in:', user);
      }
    });
  }, []);

  return <div>Firebase Authentication</div>;
};

export default FirebaseAuth;
