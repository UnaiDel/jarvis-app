// Contenido de ResponseDisplay.js
import React from 'react';

const ResponseDisplay = ({ response }) => (
  <div>
    <h2>Response from GPT:</h2>
    <p>{response}</p>
  </div>
);

export default ResponseDisplay;
