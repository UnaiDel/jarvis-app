// Contenido de apiService.js
const apiUrl = '/api';

export const sendGptRequest = async (prompt) => {
  const response = await fetch(`${apiUrl}/gpt`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ prompt }),
  });
  return response.json();
};
