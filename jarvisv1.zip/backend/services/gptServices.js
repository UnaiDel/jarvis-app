// Contenido de gptServices.js
const openai = require('openai');

module.exports = {
  generateResponse: async (prompt) => {
    const response = await openai.createCompletion({ prompt });
    return response.data;
  },
};
