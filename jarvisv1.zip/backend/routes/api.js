// Contenido de api.js
const express = require('express');
const router = express.Router();
const gptController = require('../controllers/gptController');
const puppeteerController = require('../controllers/puppeteerController');

router.post('/gpt', gptController.processGPTRequest);
router.post('/screenshot', puppeteerController.takeScreenshot);

module.exports = router;
