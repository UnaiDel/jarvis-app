// Contenido de gptController.test.js
const request = require('supertest');
const app = require('../index');

describe('POST /gpt', () => {
  it('should process GPT request', async () => {
    const res = await request(app).post('/api/gpt').send({ prompt: 'Hello' });
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('message');
  });
});
