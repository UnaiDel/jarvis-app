// Contenido de puppeteerService.test.js
const puppeteerService = require('../services/puppeteerService');

test('should capture a screenshot', async () => {
  const screenshot = await puppeteerService.captureScreenshot(
    'https://example.com',
  );
  expect(screenshot).toBeTruthy();
});
