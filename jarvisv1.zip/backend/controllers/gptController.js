// Contenido de gptController.js
module.exports = {
  processGPTRequest: async (req, res) => {
    try {
      // Lógica para manejar la solicitud a GPT
      res.status(200).json({ message: 'GPT request processed successfully' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to process GPT request' });
    }
  },
};
